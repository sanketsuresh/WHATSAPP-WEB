#!/bin/bash

echo "💾 Quick Save - WhatsApp Web Clone Project"
echo "=========================================="

# Get timestamp
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
PROJECT_NAME="WHATSAPP-WEB-CLONE"

# Create quick backup
echo "📦 Creating quick backup..."
tar -czf "QUICK-BACKUP-$PROJECT_NAME-$TIMESTAMP.tar.gz" --exclude="node_modules" --exclude="dist" --exclude=".git" .

if [ $? -eq 0 ]; then
    SIZE=$(du -h "QUICK-BACKUP-$PROJECT_NAME-$TIMESTAMP.tar.gz" | cut -f1)
    echo "✅ Quick backup created: QUICK-BACKUP-$PROJECT_NAME-$TIMESTAMP.tar.gz"
    echo "📏 Size: $SIZE"
    echo ""
    echo "💡 This backup includes:"
    echo "   ✅ Source code"
    echo "   ✅ Configuration files"
    echo "   ✅ Scripts and documentation"
    echo "   ❌ node_modules (can be reinstalled)"
    echo "   ❌ dist (can be rebuilt)"
    echo ""
    echo "🔒 Your project is saved!"
    echo "🚀 Ready for deployment!"
else
    echo "❌ Backup failed!"
    exit 1
fi
